"use client";

import GamePage from "./play/page";

export default function Home() {
  return <GamePage />;
}
