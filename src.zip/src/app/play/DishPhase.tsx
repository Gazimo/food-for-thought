import { GuessFeedback } from "@/components/GuessFeedback";
import { GuessInput } from "@/components/GuessInput";
import { useGameStore } from "@/store/gameStore";
import { TileGrid } from "../../components/dish-image/TileGrid";

interface DishPhaseProps {
  isComplete?: boolean;
}

export function DishPhase({ isComplete }: DishPhaseProps) {
  const { guessDish, dishGuesses, currentDish, revealedTiles, gameResults } =
    useGameStore();
  return (
    <>
      {currentDish?.imageUrl && (
        <TileGrid
          imageUrl={currentDish.imageUrl}
          revealedTiles={revealedTiles}
        />
      )}
      {!isComplete && (
        <div className="flex flex-col gap-2">
          <div>
            <GuessInput
              placeholder="Enter a dish name..."
              onGuess={guessDish}
              previousGuesses={dishGuesses}
              isComplete={isComplete}
              acceptableGuesses={currentDish?.acceptableGuesses}
            />
            <div className="text-sm text-gray-600 mt-1">
              Guesses: {gameResults.dishGuesses.length} of 6
            </div>
            {gameResults.dishGuesses.length > 0 &&
              !gameResults.dishGuessSuccess && (
                <div className="flex flex-wrap gap-1">
                  {gameResults.dishGuesses.map((guess, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 text-xs bg-red-100 text-red-700 rounded border"
                    >
                      {guess}
                    </span>
                  ))}
                </div>
              )}
          </div>
        </div>
      )}
      <GuessFeedback />
    </>
  );
}
