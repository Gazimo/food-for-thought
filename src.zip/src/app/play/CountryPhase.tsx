import { CountryGuessFeedback } from "@/components/CountryGuessFeedback";
import { GuessFeedback } from "@/components/GuessFeedback";
import { GuessInput } from "@/components/GuessInput";
import { useGameStore } from "@/store/gameStore";
import { Button } from "../../components/ui/button";
import { getCountryNames } from "../../utils/countries";

interface CountryPhaseProps {
  isComplete?: boolean;
}

export function CountryPhase({ isComplete }: CountryPhaseProps) {
  const { guessCountry, countryGuessResults, revealAllTiles, completeGame } =
    useGameStore();
  const countryNames = getCountryNames();
  return (
    <>
      <h2 className="text-xl font-semibold mb-4">Guess the Country</h2>
      {!isComplete && (
        <>
          <GuessInput
            placeholder="Enter a country name..."
            onGuess={guessCountry}
            suggestions={countryNames}
          />
          <Button
            className="mt-2"
            variant="fun"
            onClick={() => {
              revealAllTiles();
              completeGame();
            }}
          >
            Give Up 😩
          </Button>
        </>
      )}
      <CountryGuessFeedback guessResults={countryGuessResults} />
      <GuessFeedback />
    </>
  );
}
